# Smart Electricity Consumption Analyzer

## 1. Project Overview

This project analyzes household electricity consumption using appliance usage data and linear algebra techniques. The aim is to estimate appliance-wise power consumption from daily usage hours and total electricity readings.

## 2. Dataset Description

The initial dataset is synthetically generated using Python, NumPy, and Pandas. It represents 30 days of simulated household appliance usage. No real household meter readings were collected.

### Appliance Database

| Appliance | Assumed Power (W) |
|---|---:|
| Fan | 75 |
| LED Light | 10 |
| Computer | 120 |
| Television | 80 |
| Washing Machine | 500 |

These are assumed values for the project and may differ from actual appliance ratings.

### Daily Usage Dataset

The daily dataset contains 30 records. Each record includes:
- Day number
- Daily usage hours for each appliance
- Calculated energy consumption for each appliance
- Total daily electricity consumption in kWh

## 3. Methodology

The energy consumed by each appliance is calculated using:

Energy (kWh) = Power (W) × Usage Time (hours) / 1000

Daily total consumption is calculated by summing the energy consumption of all five appliances.

## 4. Tools and Libraries

- Python
- NumPy
- Pandas
- Matplotlib (available for future visualization)

## 5. Files

- `src/generate_data.py` — generates the synthetic data.
- `data/appliance_database.csv` — contains appliance names and assumed power ratings.
- `data/electricity_usage_30_days.csv` — contains daily usage and calculated energy consumption.
- `src/check_data.py`- hecks whether the data is valid and usable for the mathematical calculations. Full column rank means rank of matrix is equal to number of columns. Only when \(A\) has full column rank, \(A^TA\) is invertible, thus least squares can be found(Ax=B).

## 6. Limitations

The initial dataset uses known, assumed appliance power ratings to calculate total consumption. It is an ideal simulated dataset, not a representation of actual household measurements. Future experiments may add measurement noise or use real readings if available.

## 7. Reproducibility

The data-generation script uses a fixed random seed, so the same usage dataset can be generated again consistently.


## Member 2 — Least-Squares Estimation Module

Run `python src/estimation.py` to estimate appliance coefficients, predict daily consumption, calculate residuals, and write results to `outputs/`. See `MATHEMATICAL_DOCUMENTATION.md` for the derivation, assumptions, and limitations.

# Member 3: Visualization and Dashboard

## 1. Project Overview

The Visualization and Dashboard module is a part of the **Smart Electricity Consumption Analyzer** project. Its main purpose is to present electricity consumption data in a simple, interactive, and understandable visual format.

The dashboard helps users compare actual electricity consumption with predicted consumption, analyze appliance-wise energy usage, and understand prediction errors.

## 2. Technologies Used

- **Python:** Main programming language.
- **Streamlit:** Used to develop the interactive web dashboard.
- **Pandas:** Used to load, filter, process, and analyze CSV data.
- **Plotly:** Used to create interactive graphs and charts.

## 3. Features Implemented

### 3.1 Daily Actual vs. Predicted Consumption

Displays a line graph comparing actual and predicted electricity consumption for each day. This helps users observe consumption patterns and differences between readings.

### 3.2 Total Consumption Comparison

Displays a bar chart comparing the total actual electricity consumption with the total predicted consumption for the selected date range.

### 3.3 Appliance-Wise Energy Consumption

Displays a bar chart showing estimated electricity consumption for individual appliances, such as fans, LED lights, computers, televisions, and washing machines.

### 3.4 Appliance Contribution Percentage

Uses a pie chart to show each appliance's estimated contribution to the total appliance-wise consumption.

### 3.5 Prediction Error Analysis

Calculates and displays performance metrics such as Mean Absolute Error (MAE), Root Mean Squared Error (RMSE), and Mean Absolute Percentage Error (MAPE). An error graph helps identify differences between actual and predicted readings.

### 3.6 Interactive Day-Range Selection

Allows users to select a range of days using a slider. The dashboard updates the relevant consumption graphs, metrics, and daily results according to the selected range.

### 3.7 Energy-Saving Suggestions

Provides general recommendations for reducing electricity consumption, including switching off unused appliances, using LED lights, and monitoring daily electricity usage.

### 3.8 Data Table and CSV Download

Displays the selected daily consumption records in a table and allows users to download the results as a CSV file. Appliance analysis can also be downloaded separately.

## 4. Input Files

The dashboard uses the following CSV files generated or maintained by the project:

- `data/electricity_usage_30_days.csv` — Contains appliance usage data.
- `outputs/daily_predictions.csv` — Contains daily actual and predicted consumption.
- `outputs/estimated_coefficients.csv` — Contains estimated appliance consumption coefficients.

## 5. How to Run the Dashboard

Install the required libraries:

```bash
python -m pip install streamlit pandas plotly matplotlib numpy
```

Run the dashboard from the main project directory:

```bash
streamlit run src/dashboard.py
```

The dashboard opens in a web browser.

## 6. Expected Output

The dashboard provides interactive graphs, consumption summaries, appliance-wise analysis, prediction error metrics, energy-saving suggestions, and downloadable CSV reports.

## 7. Limitations

The reliability of the results depends on the quality of the input data, the accuracy of appliance usage information, and the assumptions used to estimate electricity consumption. If simulated data is used, matching actual and predicted values does not necessarily demonstrate accuracy on real household electricity readings.

## 8. Conclusion

The Visualization and Dashboard module makes the Smart Electricity Consumption Analyzer easier to understand and use. It presents mathematical estimation results through interactive charts, performance metrics, and downloadable reports, helping users explore household electricity consumption and identify potential energy-saving opportunities.
