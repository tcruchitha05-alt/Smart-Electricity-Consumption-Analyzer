# Member 2 — Linear Algebra and Least-Squares Model

## Objective
Estimate the energy-use coefficient of each appliance from daily appliance usage hours and total household electricity consumption. Produce predicted readings and residual errors.

## Dataset
The module uses `data/electricity_usage_30_days.csv`, a 30-day **synthetic** dataset with five usage-hour columns and `Total_kWh`. The dataset was generated from assumed appliance power ratings, so it is useful for demonstrating the method but does not represent actual household measurements.

## Mathematical model
Let the five appliances be fan, LED light, computer, television, and washing machine.

- `A` is an `m × n` usage matrix. Each row is a day and each column contains one appliance's usage hours.
- `x` is the `n × 1` unknown coefficient vector in kWh per recorded operating hour.
- `b` is the `m × 1` vector of observed daily total consumption in kWh.

The model is:

\[
Ax \approx b
\]

The least-squares estimate minimizes the squared residual norm:

\[
\hat{x}=\underset{x}{\operatorname{argmin}}\;\|Ax-b\|_2^2
\]

At the minimum, the normal equations are:

\[
A^T A\hat{x}=A^T b
\]

If `A` has full column rank, the solution is unique and can be expressed as:

\[
\hat{x}=(A^T A)^{-1}A^T b
\]

The code uses `numpy.linalg.lstsq(A, b, rcond=None)` instead of explicitly computing a matrix inverse, which is generally more numerically reliable.

## Predictions and residuals

Predicted daily consumption:

\[
\hat{b}=A\hat{x}
\]

Residual for each day:

\[
r=b-\hat{b}
\]

Error metrics:

\[
\mathrm{MAE}=\frac{1}{m}\sum_{i=1}^{m}|r_i|
\qquad
\mathrm{RMSE}=\sqrt{\frac{1}{m}\sum_{i=1}^{m}r_i^2}
\]

The residual sum of squares (SSE) is `sum(r**2)`. Smaller errors indicate that the model's predictions are closer to the readings used to fit it.

## How to run
1. Install Python 3.
2. Open a terminal in the `SmartElectricity_Member2` folder.
3. Install dependencies if necessary: `python -m pip install numpy pandas`.
4. Run: `python src/estimation.py`.
5. Check the generated files in `outputs/`.

## Output files
- `outputs/estimated_coefficients.csv`: estimated coefficient for each appliance, plus a watt-equivalent value.
- `outputs/daily_predictions.csv`: actual reading, predicted reading, residual and absolute error for every day.
- `outputs/estimation_summary.txt`: matrix rank, estimated coefficients and model error metrics.

## Assumptions and limitations
1. The relationship between usage hours and total energy is approximated as linear.
2. Meter totals and appliance usage hours cover the same days.
3. Usage patterns must vary enough for the columns of `A` to be linearly independent. Check the matrix rank; full column rank is required for unique coefficient estimates.
4. The model treats each appliance's energy per recorded hour as constant over the dataset.
5. The dataset is synthetic and total consumption was calculated using the same assumed ratings. Therefore, near-zero residuals demonstrate that the code works on the generated data, not that it will be equally accurate on real homes.
6. Real readings may include untracked appliances, standby power, varying appliance cycles and meter noise. Real deployment should include these effects or use suitable calibration data.

## Suggested explanation for presentation
"We form a usage matrix from the daily appliance hours and a measurement vector from the daily meter readings. NumPy's least-squares solver estimates the appliance coefficients that minimize squared prediction errors. We then calculate predicted consumption, residuals, MAE and RMSE to assess how well the model fits the data."
