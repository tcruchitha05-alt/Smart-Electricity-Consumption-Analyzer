
from pathlib import Path

import numpy as np
import pandas as pd

# --------------------------------------------------
# 1. Set up project paths
# --------------------------------------------------

PROJECT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Use a fixed seed so the data is reproducible
rng = np.random.default_rng(42)

# --------------------------------------------------
# 2. Create the appliance database
# --------------------------------------------------

appliances = pd.DataFrame({
    "Appliance": [
        "Fan",
        "LED Light",
        "Computer",
        "Television",
        "Washing Machine",
    ],
    "Power_W": [75, 10, 120, 80, 500],
})

appliances["Power_kW"] = appliances["Power_W"] / 1000

appliance_path = DATA_DIR / "appliance_database.csv"
appliances.to_csv(appliance_path, index=False)

# --------------------------------------------------
# 3. Generate 30 days of appliance usage
# --------------------------------------------------

days = np.arange(1, 31)

usage = pd.DataFrame({
    "Day": days,
    "Fan_hours": rng.integers(4, 13, size=30),
    "LED_Light_hours": rng.integers(3, 9, size=30),
    "Computer_hours": rng.integers(1, 9, size=30),
    "Television_hours": rng.integers(1, 6, size=30),
    "Washing_Machine_hours": rng.choice(
        [0.0, 0.5, 1.0, 1.5, 2.0],
        size=30,
    ),
})

# --------------------------------------------------
# 4. Calculate daily electricity consumption
# --------------------------------------------------

power_kw = {
    "Fan_hours": 0.075,
    "LED_Light_hours": 0.010,
    "Computer_hours": 0.120,
    "Television_hours": 0.080,
    "Washing_Machine_hours": 0.500,
}

energy_columns = []

for usage_column, power in power_kw.items():
    energy_column = usage_column.replace("_hours", "_kWh")
    usage[energy_column] = usage[usage_column] * power
    energy_columns.append(energy_column)

usage["Total_kWh"] = usage[energy_columns].sum(axis=1)

# --------------------------------------------------
# 5. Validate and save the dataset
# --------------------------------------------------

assert len(usage) == 30, "Expected exactly 30 days."
assert usage.isnull().sum().sum() == 0, "Missing values found."
assert (usage.select_dtypes(include="number") >= 0).all().all(), (
    "Negative values found."
)

usage_path = DATA_DIR / "electricity_usage_30_days.csv"
usage.to_csv(usage_path, index=False, float_format="%.3f")

# --------------------------------------------------
# 6. Display a summary
# --------------------------------------------------

print("Data generation successful!")

print("\nAppliance database:")
print(appliances.to_string(index=False))

print("\nFirst five days of usage:")
print(usage.head().round(3).to_string(index=False))

print(f"\nAverage daily consumption: {usage['Total_kWh'].mean():.3f} kWh")
print(f"Total consumption over 30 days: {usage['Total_kWh'].sum():.3f} kWh")

appliance_path = DATA_DIR / "appliance_database.csv"
appliances.to_csv(appliance_path, index=False)

usage_path = DATA_DIR / "electricity_usage_30_days.csv"
usage.to_csv(usage_path, index=False, float_format="%.3f")