"""Member 2: Linear Algebra and Least-Squares Estimation.

Loads the project's 30-day dataset, estimates appliance energy coefficients,
calculates predicted daily consumption and residual errors, and saves outputs.
Run from any directory with: python src/estimation.py
"""
from pathlib import Path
import numpy as np
import pandas as pd

PROJECT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_DIR / "data"
OUTPUT_DIR = PROJECT_DIR / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

USAGE_COLUMNS = [
    "Fan_hours",
    "LED_Light_hours",
    "Computer_hours",
    "Television_hours",
    "Washing_Machine_hours",
]
APPLIANCE_NAMES = ["Fan", "LED Light", "Computer", "Television", "Washing Machine"]


def run_estimation():
    data_path = DATA_DIR / "electricity_usage_30_days.csv"
    if not data_path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {data_path}\n"
            "Keep the data folder and src folder inside the project directory."
        )

    df = pd.read_csv(data_path)
    required = ["Day", "Total_kWh", *USAGE_COLUMNS]
    missing = [column for column in required if column not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing required columns: {missing}")
    if df[required].isnull().any().any():
        raise ValueError("Missing values were found in required dataset columns.")

    # A: usage matrix (rows = days, columns = appliances)
    # b: observed total daily meter consumption in kWh
    A = df[USAGE_COLUMNS].to_numpy(dtype=float)
    b = df["Total_kWh"].to_numpy(dtype=float)

    # Solve min ||A x - b||_2^2 without explicitly inverting A.T @ A.
    x_hat, _, rank, singular_values = np.linalg.lstsq(A, b, rcond=None)
    predicted = A @ x_hat
    residuals = b - predicted

    # Coefficients are in kWh per recorded operating hour.
    coefficient_table = pd.DataFrame({
        "Appliance": APPLIANCE_NAMES,
        "Estimated_kWh_per_hour": x_hat,
        "Estimated_W_equivalent": x_hat * 1000,
    })
    coefficient_table.to_csv(OUTPUT_DIR / "estimated_coefficients.csv", index=False, float_format="%.8f")

    results = pd.DataFrame({
        "Day": df["Day"],
        "Actual_kWh": b,
        "Predicted_kWh": predicted,
        "Residual_kWh": residuals,
        "Absolute_Error_kWh": np.abs(residuals),
    })
    results.to_csv(OUTPUT_DIR / "daily_predictions.csv", index=False, float_format="%.8f")

    mae = float(np.mean(np.abs(residuals)))
    rmse = float(np.sqrt(np.mean(residuals ** 2)))
    sse = float(np.sum(residuals ** 2))
    rank_ok = rank == A.shape[1]

    report = [
        "SMART ELECTRICITY CONSUMPTION ANALYZER",
        "Member 2 — Linear Algebra and Least-Squares Model",
        "=" * 55,
        f"Number of observations: {A.shape[0]}",
        f"Number of appliance coefficients: {A.shape[1]}",
        f"Matrix shape: {A.shape}",
        f"Matrix rank: {rank}",
        f"Full column rank: {'Yes' if rank_ok else 'No'}",
        "",
        "Estimated appliance coefficients:",
    ]
    for name, value in zip(APPLIANCE_NAMES, x_hat):
        report.append(f"  {name}: {value:.6f} kWh/hour ({value * 1000:.2f} W equivalent)")
    report += [
        "",
        "Model quality:",
        f"  Sum of squared residuals (SSE): {sse:.12f} kWh^2",
        f"  Mean absolute error (MAE): {mae:.8f} kWh/day",
        f"  Root mean squared error (RMSE): {rmse:.8f} kWh/day",
        "",
        "Interpretation:",
        "  A full-column-rank matrix means the five coefficients can be uniquely",
        "  estimated in this linear model. The dataset is synthetic and its total",
        "  consumption was generated from the same assumed appliance rates, so the",
        "  very small residuals are expected; this is not validation on real meter data.",
        "",
        "Files written:",
        "  outputs/estimated_coefficients.csv",
        "  outputs/daily_predictions.csv",
        "  outputs/estimation_summary.txt",
    ]
    summary = "\n".join(report) + "\n"
    (OUTPUT_DIR / "estimation_summary.txt").write_text(summary, encoding="utf-8")
    print(summary)
    print("First five daily predictions:")
    print(results.head().round(5).to_string(index=False))
    return coefficient_table, results


if __name__ == "__main__":
    run_estimation()
