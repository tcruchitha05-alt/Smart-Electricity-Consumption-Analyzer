
import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

# --------------------------------------------------
# 1. PAGE CONFIGURATION
# --------------------------------------------------

st.set_page_config(
    page_title="Smart Electricity Consumption Analyzer",
    page_icon="⚡",
    layout="wide"
)

st.title("⚡ Smart Electricity Consumption Analyzer")
st.markdown(
    "### Household Electricity Consumption Prediction and Analysis"
)
st.write(
    "Analyze electricity consumption, compare actual and predicted "
    "readings, and understand appliance-wise energy usage."
)

# --------------------------------------------------
# 2. FILE PATHS
# --------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent

DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "outputs"

DAILY_FILE = OUTPUT_DIR / "daily_predictions.csv"
COEFFICIENT_FILE = OUTPUT_DIR / "estimated_coefficients.csv"
USAGE_FILE = DATA_DIR / "electricity_usage_30_days.csv"

# --------------------------------------------------
# 3. LOAD DATA
# --------------------------------------------------

@st.cache_data
def load_data():
    daily_df = pd.read_csv(DAILY_FILE)
    coefficients_df = pd.read_csv(COEFFICIENT_FILE)
    usage_df = pd.read_csv(USAGE_FILE)

    return daily_df, coefficients_df, usage_df


try:
    daily_df, coefficients_df, usage_df = load_data()

except FileNotFoundError as error:
    st.error(f"Required data file not found: {error.filename}")
    st.info(
        "Check that the data and outputs folders exist and "
        "that the required CSV files are present."
    )
    st.stop()

except Exception as error:
    st.error(f"Unable to load the project data: {error}")
    st.stop()


# --------------------------------------------------
# 4. VALIDATE REQUIRED COLUMNS
# --------------------------------------------------

required_daily = {"Day", "Actual_kWh", "Predicted_kWh"}

required_coefficients = {
    "Appliance",
    "Estimated_kWh_per_hour"
}

if not required_daily.issubset(daily_df.columns):
    st.error(
        "daily_predictions.csv must contain: "
        "Day, Actual_kWh, Predicted_kWh"
    )
    st.stop()

if not required_coefficients.issubset(coefficients_df.columns):
    st.error(
        "estimated_coefficients.csv must contain: "
        "Appliance, Estimated_kWh_per_hour"
    )
    st.stop()

if daily_df.empty or coefficients_df.empty or usage_df.empty:
    st.error("One or more CSV files contain no data.")
    st.stop()

daily_df["Day"] = pd.to_numeric(
    daily_df["Day"], errors="coerce"
)
daily_df["Actual_kWh"] = pd.to_numeric(
    daily_df["Actual_kWh"], errors="coerce"
)
daily_df["Predicted_kWh"] = pd.to_numeric(
    daily_df["Predicted_kWh"], errors="coerce"
)

coefficients_df["Estimated_kWh_per_hour"] = pd.to_numeric(
    coefficients_df["Estimated_kWh_per_hour"],
    errors="coerce"
)

daily_df = daily_df.dropna(
    subset=["Day", "Actual_kWh", "Predicted_kWh"]
).sort_values("Day")

coefficients_df = coefficients_df.dropna(
    subset=["Appliance", "Estimated_kWh_per_hour"]
)

if daily_df.empty or coefficients_df.empty:
    st.error("The CSV files do not contain usable numeric data.")
    st.stop()


# --------------------------------------------------
# 5. SIDEBAR AND DAY-RANGE FILTER
# --------------------------------------------------

st.sidebar.header("⚙️ Dashboard Controls")

min_day = int(daily_df["Day"].min())
max_day = int(daily_df["Day"].max())

st.sidebar.write("Select the days to analyze:")

day_range = st.sidebar.slider(
    "Day Range",
    min_value=min_day,
    max_value=max_day,
    value=(min_day, max_day)
)

filtered_df = daily_df[
    (daily_df["Day"] >= day_range[0])
    & (daily_df["Day"] <= day_range[1])
].copy()

if filtered_df.empty:
    st.warning("No readings are available for this day range.")
    st.stop()

st.sidebar.success(
    f"Analyzing days {day_range[0]} to {day_range[1]}"
)

# --------------------------------------------------
# 6. CALCULATE PERFORMANCE METRICS
# --------------------------------------------------

actual_total = filtered_df["Actual_kWh"].sum()
predicted_total = filtered_df["Predicted_kWh"].sum()

absolute_errors = (
    filtered_df["Actual_kWh"]
    - filtered_df["Predicted_kWh"]
).abs()

mae = absolute_errors.mean()

rmse = (
    (
        filtered_df["Actual_kWh"]
        - filtered_df["Predicted_kWh"]
    ) ** 2
).mean() ** 0.5

# Mean absolute percentage error.
# Ignore zero actual readings because division by zero is undefined.
nonzero_actual = filtered_df[
    filtered_df["Actual_kWh"] != 0
]

if not nonzero_actual.empty:
    mape = (
        (
            (
                nonzero_actual["Actual_kWh"]
                - nonzero_actual["Predicted_kWh"]
            ).abs()
            / nonzero_actual["Actual_kWh"].abs()
        ).mean()
        * 100
    )
else:
    mape = None

# --------------------------------------------------
# 7. KPI METRICS
# --------------------------------------------------

st.subheader("📊 Consumption Overview")

col1, col2, col3, col4 = st.columns(4)

col1.metric(
    "Actual Consumption",
    f"{actual_total:.2f} kWh"
)

col2.metric(
    "Predicted Consumption",
    f"{predicted_total:.2f} kWh"
)

col3.metric(
    "Mean Absolute Error",
    f"{mae:.3f} kWh"
)

col4.metric(
    "MAPE",
    f"{mape:.2f}%" if mape is not None else "N/A"
)

st.caption(
    f"Metrics are calculated using the selected days "
    f"({day_range[0]}–{day_range[1]}). "
    "MAPE excludes readings where actual consumption is zero."
)

# --------------------------------------------------
# 8. ACTUAL VS PREDICTED DAILY CONSUMPTION
# --------------------------------------------------

st.divider()
st.subheader("📈 Daily Actual vs Predicted Consumption")

comparison_df = filtered_df.melt(
    id_vars=["Day"],
    value_vars=["Actual_kWh", "Predicted_kWh"],
    var_name="Reading Type",
    value_name="Consumption (kWh)"
)

comparison_df["Reading Type"] = comparison_df[
    "Reading Type"
].replace({
    "Actual_kWh": "Actual Consumption",
    "Predicted_kWh": "Predicted Consumption"
})

fig_comparison = px.line(
    comparison_df,
    x="Day",
    y="Consumption (kWh)",
    color="Reading Type",
    markers=True,
    title="Actual and Predicted Consumption by Day",
    labels={
        "Day": "Day",
        "Consumption (kWh)": "Electricity (kWh)"
    }
)

fig_comparison.update_layout(
    hovermode="x unified"
)

st.plotly_chart(
    fig_comparison,
    use_container_width=True
)

# --------------------------------------------------
# 9. TOTAL CONSUMPTION COMPARISON
# --------------------------------------------------

st.subheader("⚖️ Total Consumption Comparison")

total_comparison = pd.DataFrame({
    "Type": ["Actual", "Predicted"],
    "Consumption (kWh)": [
        actual_total,
        predicted_total
    ]
})

fig_total = px.bar(
    total_comparison,
    x="Type",
    y="Consumption (kWh)",
    color="Type",
    text_auto=".2f",
    title="Total Actual vs Predicted Electricity Consumption"
)

st.plotly_chart(
    fig_total,
    use_container_width=True
)

# --------------------------------------------------
# 10. APPLIANCE-WISE CONSUMPTION
# --------------------------------------------------

st.divider()
st.subheader("🔌 Appliance-Wise Energy Consumption")

# Match appliance names in the coefficient file to
# their corresponding usage columns in the usage file.

appliance_usage_columns = {
    "Fan": "Fan_hours",
    "LED Light": "LED_Light_hours",
    "LED_Light": "LED_Light_hours",
    "Computer": "Computer_hours",
    "Television": "Television_hours",
    "TV": "Television_hours",
    "Washing Machine": "Washing_Machine_hours",
    "Washing_Machine": "Washing_Machine_hours"
}

appliance_rows = []

# Align usage data with selected days, if the usage file
# has one row for each day and the same ordering.

for _, row in coefficients_df.iterrows():

    appliance_name = str(row["Appliance"]).strip()
    coefficient = row["Estimated_kWh_per_hour"]

    usage_column = appliance_usage_columns.get(
        appliance_name
    )

    if usage_column is None:
        # Try matching the appliance name with a usage
        # column, ignoring spaces and underscores.
        normalized_name = (
            appliance_name.lower()
            .replace(" ", "")
            .replace("_", "")
        )

        for column in usage_df.columns:
            if column.lower().endswith("_hours"):
                normalized_column = (
                    column.lower()
                    .replace("_hours", "")
                    .replace("_", "")
                    .replace(" ", "")
                )

                if normalized_column == normalized_name:
                    usage_column = column
                    break

    if usage_column is None or usage_column not in usage_df.columns:
        continue

    if len(usage_df) == len(daily_df):
        # The usage rows and daily prediction rows are aligned.
        selected_days = filtered_df["Day"].astype(int)

        usage_indices = [
            int(day - min_day)
            for day in selected_days
            if 0 <= int(day - min_day) < len(usage_df)
        ]

        hours_used = usage_df.iloc[
            usage_indices
        ][usage_column].sum()

    else:
        # If the files cannot be aligned by day, use all
        # usage rows rather than silently misaligning them.
        hours_used = usage_df[usage_column].sum()

    estimated_consumption = hours_used * coefficient

    appliance_rows.append({
        "Appliance": appliance_name,
        "Estimated Consumption (kWh)": estimated_consumption,
        "Usage Hours": hours_used,
        "Estimated kWh per Hour": coefficient
    })


appliance_df = pd.DataFrame(appliance_rows)

if appliance_df.empty:
    st.warning(
        "No appliance usage columns matched the coefficient file. "
        "Check the appliance names and usage column names."
    )

else:
    appliance_df = appliance_df.sort_values(
        "Estimated Consumption (kWh)",
        ascending=False
    )

    col1, col2 = st.columns(2)

    with col1:
        fig_appliance = px.bar(
            appliance_df,
            x="Appliance",
            y="Estimated Consumption (kWh)",
            text_auto=".2f",
            title="Estimated Consumption by Appliance"
        )

        fig_appliance.update_layout(
            xaxis_title="Appliance",
            yaxis_title="Estimated Consumption (kWh)"
        )

        st.plotly_chart(
            fig_appliance,
            use_container_width=True
        )

    with col2:
        pie_df = appliance_df[
            appliance_df["Estimated Consumption (kWh)"] > 0
        ]

        if not pie_df.empty:
            fig_pie = px.pie(
                pie_df,
                names="Appliance",
                values="Estimated Consumption (kWh)",
                title="Appliance Contribution (%)",
                hole=0.35
            )

            fig_pie.update_traces(
                textposition="inside",
                textinfo="percent+label"
            )

            st.plotly_chart(
                fig_pie,
                use_container_width=True
            )
        else:
            st.info(
                "There is no positive estimated appliance "
                "consumption to display."
            )

    st.dataframe(
        appliance_df.round(3),
        use_container_width=True,
        hide_index=True
    )

    appliance_total = appliance_df[
        "Estimated Consumption (kWh)"
    ].sum()

    if appliance_total > 0:
        st.caption(
            "Appliance contribution percentages are calculated "
            "from the estimated appliance consumption shown above."
        )

# --------------------------------------------------
# 11. PREDICTION ERROR ANALYSIS
# --------------------------------------------------

st.divider()
st.subheader("🎯 Prediction Error Analysis")

error_df = filtered_df[["Day"]].copy()

error_df["Error (kWh)"] = (
    filtered_df["Actual_kWh"]
    - filtered_df["Predicted_kWh"]
)

fig_error = px.bar(
    error_df,
    x="Day",
    y="Error (kWh)",
    title="Daily Prediction Error",
    labels={
        "Day": "Day",
        "Error (kWh)": "Actual - Predicted (kWh)"
    }
)

fig_error.add_hline(
    y=0,
    line_dash="dash"
)

st.plotly_chart(
    fig_error,
    use_container_width=True
)

st.write(f"**Root Mean Squared Error (RMSE):** {rmse:.3f} kWh")

if absolute_errors.max() == 0:
    st.info(
        "Actual and predicted readings match exactly in the "
        "selected data. Since this project uses simulated data, "
        "this does not establish real-world prediction accuracy."
    )
elif mae < 0.5:
    st.success(
        "The average absolute prediction error is below 0.5 kWh "
        "for the selected data."
    )
else:
    st.warning(
        "There are differences between actual and predicted "
        "readings. Review the error graph and model assumptions."
    )

# --------------------------------------------------
# 12. ENERGY-SAVING SUGGESTIONS
# --------------------------------------------------

st.divider()
st.subheader("💡 Energy-Saving Suggestions")

st.write(
    "The following general suggestions can help reduce "
    "household electricity consumption:"
)

suggestions = [
    "Switch off lights and fans when rooms are not in use.",
    "Use LED lights instead of traditional incandescent bulbs.",
    "Avoid leaving computers and televisions on unnecessarily.",
    "Run the washing machine with full loads when practical.",
    "Track daily consumption to identify unusual increases."
]

for suggestion in suggestions:
    st.markdown(f"- {suggestion}")

if not appliance_df.empty:
    highest_appliance = appliance_df.iloc[0]

    st.info(
        f"Your highest estimated-consuming appliance in this "
        f"analysis is **{highest_appliance['Appliance']}**. "
        "Review its usage hours and estimated power consumption "
        "to identify possible savings."
    )

# --------------------------------------------------
# 13. DAILY RESULTS TABLE
# --------------------------------------------------

st.divider()
st.subheader("📋 Selected Daily Results")

display_df = filtered_df.copy()

display_df["Absolute Error (kWh)"] = (
    display_df["Actual_kWh"]
    - display_df["Predicted_kWh"]
).abs()

display_df = display_df.round(3)

st.dataframe(
    display_df,
    use_container_width=True,
    hide_index=True
)

# --------------------------------------------------
# 14. DOWNLOAD SELECTED RESULTS
# --------------------------------------------------

csv_data = display_df.to_csv(
    index=False
).encode("utf-8")

st.download_button(
    label="⬇️ Download Selected Daily Results",
    data=csv_data,
    file_name="selected_daily_results.csv",
    mime="text/csv"
)

if not appliance_df.empty:
    appliance_csv = appliance_df.to_csv(
        index=False
    ).encode("utf-8")

    st.download_button(
        label="⬇️ Download Appliance Analysis",
        data=appliance_csv,
        file_name="appliance_analysis.csv",
        mime="text/csv"
    )

# --------------------------------------------------
# 15. FOOTER
# --------------------------------------------------

st.divider()

st.caption(
    "Smart Electricity Consumption Analyzer | "
    "Visualization and Dashboard Module"
)

st.caption(
    "Note: Results depend on the quality of the input data, "
    "estimated appliance coefficients, and prediction method."
)
