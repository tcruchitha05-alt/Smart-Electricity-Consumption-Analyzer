"""Member 4: What-If Analysis and Energy Savings.
Uses Member 2's estimated appliance coefficients and Member 1's 30-day dataset.
Run from the project root: python src/what_if_analysis.py
"""
from pathlib import Path
import pandas as pd

PROJECT_DIR = Path(__file__).resolve().parent.parent
DATA_PATH = PROJECT_DIR / "data" / "electricity_usage_30_days.csv"
COEFFICIENT_PATH = PROJECT_DIR / "outputs" / "estimated_coefficients.csv"
OUTPUT_PATH = PROJECT_DIR / "outputs" / "what_if_results.csv"

APPLIANCES = {
    "Fan": "Fan_hours",
    "LED Light": "LED_Light_hours",
    "Computer": "Computer_hours",
    "Television": "Television_hours",
    "Washing Machine": "Washing_Machine_hours",
}


def read_number(prompt, minimum=0):
    """Read a non-negative number from the user, repeating on invalid input."""
    while True:
        try:
            value = float(input(prompt))
            if value < minimum:
                print(f"Please enter a value of at least {minimum}.")
            else:
                return value
        except ValueError:
            print("Invalid input. Please enter a number, such as 4 or 2.5.")


def main():
    if not DATA_PATH.exists() or not COEFFICIENT_PATH.exists():
        print("Required files were not found. Run this script from the extracted project folder.")
        return

    usage_data = pd.read_csv(DATA_PATH)
    coefficient_data = pd.read_csv(COEFFICIENT_PATH)
    coefficients = dict(zip(coefficient_data["Appliance"], coefficient_data["Estimated_kWh_per_hour"]))

    # Use average observed usage in the 30-day dataset as the baseline scenario.
    baseline_hours = {name: float(usage_data[column].mean()) for name, column in APPLIANCES.items()}
    baseline_energy = sum(baseline_hours[name] * float(coefficients[name]) for name in APPLIANCES)

    print("\n=== MEMBER 4: WHAT-IF ANALYSIS AND ENERGY SAVINGS ===")
    print("Baseline usage is the average daily usage from the 30-day dataset.")
    print("\nBaseline average usage and estimated energy:")
    for name in APPLIANCES:
        print(f"{name}: {baseline_hours[name]:.2f} hours/day")
    print(f"Baseline energy: {baseline_energy:.3f} kWh/day")

    print("\nEnter the new daily usage hours for each appliance.")
    new_hours = {}
    for name in APPLIANCES:
        new_hours[name] = read_number(f"{name} hours/day (0 to 24): ")
        while new_hours[name] > 24:
            print("Daily usage cannot exceed 24 hours.")
            new_hours[name] = read_number(f"{name} hours/day (0 to 24): ")

    tariff = read_number("Electricity tariff in rupees per kWh (default 8; press Enter is not supported, type 8): ")
    new_energy = sum(new_hours[name] * float(coefficients[name]) for name in APPLIANCES)
    energy_saved = baseline_energy - new_energy
    daily_cost_difference = energy_saved * tariff
    monthly_cost_difference = daily_cost_difference * 30

    print("\n=== SCENARIO COMPARISON ===")
    print(f"Baseline energy: {baseline_energy:.3f} kWh/day")
    print(f"New scenario energy: {new_energy:.3f} kWh/day")
    print(f"Energy saved (+) / extra used (-): {energy_saved:.3f} kWh/day")
    print(f"Estimated cost saved (+) / extra cost (-): Rs. {daily_cost_difference:.2f}/day")
    print(f"Estimated 30-day cost difference: Rs. {monthly_cost_difference:.2f}")

    rows = []
    for name in APPLIANCES:
        coefficient = float(coefficients[name])
        rows.append({
            "Appliance": name,
            "Estimated_kWh_per_hour": coefficient,
            "Baseline_hours_per_day": baseline_hours[name],
            "New_hours_per_day": new_hours[name],
            "Baseline_kWh_per_day": baseline_hours[name] * coefficient,
            "New_kWh_per_day": new_hours[name] * coefficient,
            "Energy_saved_kWh_per_day": (baseline_hours[name] - new_hours[name]) * coefficient,
        })
    result = pd.DataFrame(rows)
    result.loc[len(result)] = {
        "Appliance": "TOTAL",
        "Estimated_kWh_per_hour": None,
        "Baseline_hours_per_day": None,
        "New_hours_per_day": None,
        "Baseline_kWh_per_day": baseline_energy,
        "New_kWh_per_day": new_energy,
        "Energy_saved_kWh_per_day": energy_saved,
    }
    result["Tariff_Rs_per_kWh"] = tariff
    result["Estimated_daily_cost_difference_Rs"] = daily_cost_difference
    result["Estimated_30_day_cost_difference_Rs"] = monthly_cost_difference
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(OUTPUT_PATH, index=False)
    print(f"\nDetailed results saved to: {OUTPUT_PATH.relative_to(PROJECT_DIR)}")
    print("Positive savings mean lower usage/cost; negative savings mean higher usage/cost.")


if __name__ == "__main__":
    main()
