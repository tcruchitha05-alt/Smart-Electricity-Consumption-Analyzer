
from pathlib import Path
import pandas as pd
import numpy as np

PROJECT_DIR = Path(__file__).resolve().parent.parent
DATA_PATH = PROJECT_DIR / "data" / "electricity_usage_30_days.csv"

df = pd.read_csv(DATA_PATH)

# The five input features for our model
feature_columns = [
    "Fan_hours",
    "LED_Light_hours",
    "Computer_hours",
    "Television_hours",
    "Washing_Machine_hours",
]

A = df[feature_columns].to_numpy(dtype=float)

print("Dataset shape:", df.shape)
print("Matrix A shape:", A.shape)

print("\nVariation in appliance usage:")
print(df[feature_columns].std().round(3))

print("\nMatrix rank:", np.linalg.matrix_rank(A))
print("Number of appliance features:", A.shape[1])

if np.linalg.matrix_rank(A) == A.shape[1]:
    print("\nThe input matrix has full column rank.")
else:
    print("\nThe input matrix does not have full column rank.")
