# Member 4 — What-If Analysis and Energy Savings

This module uses Member 1's 30-day appliance usage dataset and Member 2's `outputs/estimated_coefficients.csv`.

## Run in VS Code
1. Extract this ZIP file.
2. Open the `SmartElectricity_Member2` folder in VS Code.
3. In Terminal → New Terminal, install dependencies if needed:
   `python -m pip install pandas numpy`
4. Run:
   `python src/what_if_analysis.py`
5. Enter daily usage hours for each appliance (0–24) and the electricity tariff in rupees per kWh.
6. Results are displayed in the terminal and saved to `outputs/what_if_results.csv`.

The baseline is calculated from average usage in the supplied 30-day dataset. Positive savings indicate reduced consumption/cost; negative savings indicate increased consumption/cost. The tariff is an estimate and should be adjusted to match the applicable electricity rate.
